from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user,login_required
from datetime import datetime
from flask_bcrypt import Bcrypt
from flask_login import current_user


app=Flask(__name__)
bcrypt=Bcrypt(app)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite"
app.config["SECRET_KEY"] = "abc"
db = SQLAlchemy()
typ=0

login_manager = LoginManager()
login_manager.init_app(app)
 
class admin(UserMixin,db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(250), unique=True, nullable=False)
    password = db.Column(db.String(250), nullable=False)

class patient(UserMixin, db.Model):
    p_id = db.Column(db.Integer, primary_key=True)
    p_username = db.Column(db.String(250), unique=True, nullable=False)
    p_password = db.Column(db.String(250), nullable=False)
    def get_id(self):
           return (self.p_id)


class doctor(UserMixin, db.Model):
    d_id = db.Column(db.Integer, primary_key=True)
    d_username = db.Column(db.String(250), unique=True, nullable=False)
    d_password = db.Column(db.String(250), nullable=False)
    def get_id(self):
           return (self.d_id)
       
class appointment(UserMixin,db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.String, db.ForeignKey('patient.p_id'), nullable=False)
    doctor_id = db.Column(db.String, db.ForeignKey('doctor.d_id'), nullable=False)
    appointment_time = db.Column(db.String, nullable=False)
    
    patient = db.relationship('patient', foreign_keys='appointment.patient_id', backref='appointments')
    doctor = db.relationship('doctor', foreign_keys='appointment.doctor_id', backref='appointments')
    def get_time(self):
        return (self.appointment_time)
 
db.init_app(app)

with app.app_context():
    db.create_all()
 

@login_manager.user_loader
def loader_user(user_id):
    global typ
    # type = db.session.get('type')
    print(typ)
    if typ == 1:
        user = patient.query.filter_by(p_id = user_id).first()
    elif typ == 2:
        user = doctor.query.filter_by(d_id = user_id).first()
    elif typ == 3:
        user = admin.query.filter_by(id=user_id).first()
    else:
        user = None
    return user
    # return patient.query.filter_by(p_id = user_id).first()

# Making Admin initially, No need to use it afterwards
@app.route("/make/admin", methods=['GET','POST'])
def makeadmin():
    if request.method == "POST":
        user = admin(username="admin", password="power")
        db.session.add(user)
        db.session.commit()
        # output=db.session.execute(patient.select()).fetchall()
        # print(output)
        return redirect(url_for("admin_dashoard"))
    return render_template("signup_new.html")

# @app.route('/admin', methods=['GET','POST'])
# def admn():
#     global typ
#     if request.method == "POST":
#         user = admin.query.filter_by(username=request.form.get("username")).first()
#         if user and user.password == request.form.get("password"):
#             typ = 3
#             login_user(user)
#             patients = patient.query.all()
#             doctors = doctor.query.all()
#             appointments = appointment.query.all()
#             return render_template("admin.html", patients=patients, doctors=doctors, appointments=appointments)
#     return render_template("login_new.html")

# @app.route('/schedule_appointment', methods=['POST'])
# @login_required
# def schedule_appointment():
#     if request.method == "POST":
#         patient_id = request.form.get("p_id")
#         doctor_id = request.form.get("d_id")
#         appointment_time = request.form.get("appointment_time")
#         appointment = appointment(patient_id=patient_id, doctor_id=doctor_id,
#                                   appointment_time=datetime.strptime(appointment_time, '%Y-%m-%d %H:%M'))
#         db.session.add(appointment)
#         db.session.commit()
#         return redirect(url_for("admin_dashboard"))
@app.route("/admin", methods=["GET", "POST"])
def admin_dashboard():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        user = admin.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            patients = patient.query.all()
            doctors = doctor.query.all()
            appointments = appointment.query.all()
            return render_template("admin.html", patients=patients, doctors=doctors, appointments=appointments)
    return render_template("login_new.html")


@app.route("/schedule_appointment", methods=["GET" , "POST"])
def schedule_appointment():
    if request.method == "POST":
        patient_id = request.form.get("p_id")
        doctor_id = request.form.get("d_id")
        appointment_time = request.form.get("appointment_time")
        if patient_id and doctor_id:
            new_appointment = appointment(patient_id=patient_id, doctor_id=doctor_id,appointment_time=appointment_time)
            db.session.add(new_appointment)
            db.session.commit()
            return redirect(url_for("admin_dashboard"))
        else:
            print("Please select both a patient and a doctor.")
            return redirect(url_for("admin_dashboard"))
    return render_template("schedule.html")

#Patient
@app.route('/signup/patient', methods=['GET', 'POST'])
def p_signup():
    if request.method == "POST":
        user = patient(p_username=request.form.get("username"),
                     p_password=bcrypt.generate_password_hash(request.form.get("password")).decode('utf-8'))
        db.session.add(user)
        db.session.commit()
        # output=db.session.execute(patient.select()).fetchall()
        # print(output)
        return redirect(url_for("p_login"))
    return render_template("signup_new.html")
    #     new_patient = patient(p_username=username, p_password=password)
    #     db.session.add(new_patient)
    #     db.session.commit()
    #     return redirect(url_for('patient_login'))
    # doctors = doctor.query.all()
    # return render_template('patient_signup.html', doctors=doctors)
 
 
@app.route("/login/patient", methods=["GET", "POST"])
def p_login():
    global typ
    if request.method == "POST":
        user = patient.query.filter_by(
            p_username=request.form.get("username")).first()
        if user:
        #if user.password == request.form.get("password"):
            if (bcrypt.check_password_hash(user.p_password,request.form.get("password"))):
                typ=1
                login_user(user)
                # db.session['type']='p'\
                # test=db.session.query(patient).all()
                # for t in test:
                #     print(f"Patient ID: {t.p_id}")
                #     print(f"Username: {t.p_username}")
                return redirect(url_for("home"))
    return render_template("login_new.html")
 
#Doctor
@app.route('/signup/doctor', methods=['GET', 'POST'])
def d_signup():
    if request.method == "POST":
        user = doctor(d_username=request.form.get("username"),
                     d_password=bcrypt.generate_password_hash(request.form.get("password")).decode('utf-8'))
        db.session.add(user)
        db.session.commit()
        # output=db.session.execute(doctor.select()).fetchall()
        # print(output)
        return redirect(url_for("d_login"))
    return render_template("signup_new.html")

@app.route("/login/doctor", methods=["GET", "POST"])
def d_login():
    global typ
    if request.method == "POST":
        user = doctor.query.filter_by(
            d_username=request.form.get("username")).first()
        if user:
        #if user.password == request.form.get("password"):
            if (bcrypt.check_password_hash(user.d_password,request.form.get("password"))):
                typ=2
                login_user(user)
                # db.session['type']='d'
                return redirect(url_for("home"))
    return render_template("login_new.html")

@app.route("/view_appointments")
@login_required
def view_appointments():
    if typ == 1:
        patient_id = current_user.get_id()  # Get the patient's ID from the current_user object
        patient_appointments = appointment.query.filter_by(patient_id=patient_id).all()
        return render_template("appointments.html", appointments=patient_appointments,check=typ)
    elif typ==2:
        doctor_id = current_user.get_id()  # Get the patient's ID from the current_user object
        doctor_appointments = appointment.query.filter_by(doctor_id=doctor_id).all()
        return render_template("appointments.html", appointments=doctor_appointments,check=typ)
        
    else:
        return redirect(url_for("home"))

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("home"))
 


@app.route("/")
def home():
    if typ == 1:
        return redirect(url_for("view_appointments"))
    elif typ==2:
        return redirect(url_for("view_appointments"))
    else:
        return render_template("home.html")
 
 
if __name__ == "__main__":
    app.run()