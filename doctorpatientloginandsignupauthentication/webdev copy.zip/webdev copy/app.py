# authenication
from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user

app= Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite"
app.config["SECRET_KEY"] = "abc"
db= SQLAlchemy()

login_manager = LoginManager()
login_manager.init_app(app)

class Users(UserMixin,db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(250), unique = True, nullable=False)
    password = db.Column(db.String(250),nullable=False)
    
db.init_app(app)

with app.app_context():
    db.create_all()
    
@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(user_id)

@app.route('/register', methods = ["GET","POST"])
def register():
    if request.method== "POST":
        user = Users(username= request.form.get("username"),
                     password= request.form.get("password")) 
        
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("login"))
    return render_template("sign_up.html") 
                                
@app.route("/login" , methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = Users.query.filter_by(
            username= request.form.get("username")).first()
        if user.password == request.form.get("password"):
            login_user(user)
            return redirect(url_for("home"))
    return render_template("login1.html")


@app.route('/signup/doctor', methods=['GET', 'POST'])
def doctor_signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_doctor = Doctor(username=username, password=password)
        db.session.add(new_doctor)
        db.session.commit()
        return redirect(url_for('doctor_login'))
    return render_template('doctor_signup.html')

@app.route('/login/doctor', methods=['GET', 'POST'])
def doctor_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        doctor = Doctor.query.filter_by(username=username, password=password).first()
        if doctor:
            session['doctor_id'] = doctor.id
            return redirect(url_for('doctor_dashboard'))
    return render_template('doctor_login.html')

@app.route('/dashboard/doctor')
def doctor_dashboard():
    if 'doctor_id' in session:
        doctor_id = session['doctor_id']
        doctor = Doctor.query.get(doctor_id)
        patients = Patient.query.filter_by(doctor_id=doctor_id).all()
        return render_template('doctor_dashboard.html', doctor=doctor, patients=patients)
    return redirect(url_for('doctor_login'))

@app.route('/signup/patient', methods=['GET', 'POST'])
def patient_signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        doctor_id = request.form['doctor_id']
        new_patient = Patient(username=username, password=password, doctor_id=doctor_id)
        db.session.add(new_patient)
        db.session.commit()
        return redirect(url_for('patient_login'))
    doctors = Doctor.query.all()
    return render_template('patient_signup.html', doctors=doctors)

@app.route('/login/patient', methods=['GET', 'POST'])
def patient_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        patient = Patient.query.filter_by(username=username, password=password).first()
        if patient:
            session['patient_id'] = patient.id
            return redirect(url_for('patient_dashboard'))
    return render_template('patient_login.html')

@app.route('/dashboard/patient')
def patient_dashboard():
    if 'patient_id' in session:
        patient_id = session['patient_id']
        patient = Patient.query.get(patient_id)
        appointments = Appointment.query.filter_by(patient_id=patient_id).all()
        return render_template('patient_dashboard.html', patient=patient, appointments=appointments)
    return redirect(url_for('patient_login'))

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("home"))

@app.route("/")
def home():
    return render_template("home1.html")

if __name__== "__main__":
    app.run()